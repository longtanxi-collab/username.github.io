const $ = (id) => document.getElementById(id);

const VISION_TASKS_URL = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14";
const MODEL_URL = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/latest/face_landmarker.task";
const WASM_URL = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm";

const state = {
  landmarker: null,
  modelReady: false,
  metrics: null,
  selectedFaceIndex: 0,
  image: null
};

const refs = {
  modelStatus: $("modelStatus"),
  scanMessage: $("scanMessage"),
  dropZone: $("dropZone"),
  photoInput: $("photoInput"),
  photoPreview: $("photoPreview"),
  canvas: $("overlayCanvas")
};

function setStatus(text, type = "") {
  refs.modelStatus.textContent = text;
  refs.modelStatus.className = `status-pill ${type}`.trim();
}

function setMessage(text, type = "") {
  refs.scanMessage.textContent = text;
  refs.scanMessage.className = `scan-message ${type}`.trim();
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function distance(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

function average(points) {
  return points.reduce((sum, point) => sum + point, 0) / points.length;
}

function metricPercent(value, min, max) {
  return `${clamp(Math.round(((value - min) / (max - min)) * 100), 6, 100)}%`;
}

async function initFaceLandmarker() {
  try {
    setStatus("模型加载中");
    const { FaceLandmarker, FilesetResolver } = await import(VISION_TASKS_URL);
    const vision = await FilesetResolver.forVisionTasks(WASM_URL);

    const createLandmarker = (delegate) => FaceLandmarker.createFromOptions(vision, {
      baseOptions: {
        modelAssetPath: MODEL_URL,
        delegate
      },
      runningMode: "IMAGE",
      numFaces: 5
    });

    try {
      state.landmarker = await createLandmarker("GPU");
    } catch (gpuError) {
      console.warn("GPU delegate unavailable, falling back to CPU.", gpuError);
      state.landmarker = await createLandmarker("CPU");
    }

    state.modelReady = true;
    setStatus("AI已就绪", "ready");
    setMessage("模型已就绪。上传正脸照片后会自动识别人脸、标注关键点并生成报告。", "success");
  } catch (error) {
    state.modelReady = false;
    setStatus("模型加载失败", "error");
    setMessage("人脸识别模型加载失败，请检查网络后刷新页面。照片不会上传服务器。", "warning");
    console.error(error);
  }
}

function readImage(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = () => {
      const image = new Image();
      image.onload = () => resolve({ image, dataUrl: reader.result });
      image.onerror = reject;
      image.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

function chooseLargestFace(faces) {
  let maxArea = -1;
  let index = 0;
  faces.forEach((face, faceIndex) => {
    const xs = face.map((point) => point.x);
    const ys = face.map((point) => point.y);
    const area = (Math.max(...xs) - Math.min(...xs)) * (Math.max(...ys) - Math.min(...ys));
    if (area > maxArea) {
      maxArea = area;
      index = faceIndex;
    }
  });
  return index;
}

function calculateMetrics(landmarks) {
  const faceTop = landmarks[10];
  const chin = landmarks[152];
  const leftFace = landmarks[234];
  const rightFace = landmarks[454];
  const noseBridge = landmarks[168];
  const noseBottom = landmarks[2];
  const noseLeft = landmarks[98];
  const noseRight = landmarks[327];
  const mouthLeft = landmarks[61];
  const mouthRight = landmarks[291];
  const leftEyeOuter = landmarks[33];
  const leftEyeInner = landmarks[133];
  const rightEyeInner = landmarks[362];
  const rightEyeOuter = landmarks[263];
  const leftEyeTop = landmarks[159];
  const leftEyeBottom = landmarks[145];
  const rightEyeTop = landmarks[386];
  const rightEyeBottom = landmarks[374];

  const browY = average([
    landmarks[70].y, landmarks[63].y, landmarks[105].y, landmarks[66].y, landmarks[107].y,
    landmarks[336].y, landmarks[296].y, landmarks[334].y, landmarks[293].y, landmarks[300].y
  ]);

  const faceWidth = distance(leftFace, rightFace);
  const faceLength = distance(faceTop, chin);
  const faceRatio = faceLength / faceWidth;
  const upperThird = Math.abs(browY - faceTop.y) / faceLength;
  const middleThird = Math.abs(noseBottom.y - browY) / faceLength;
  const lowerThird = Math.abs(chin.y - noseBottom.y) / faceLength;
  const eyeSpacing = distance(leftEyeInner, rightEyeInner) / faceWidth;
  const leftEyeSize = distance(leftEyeOuter, leftEyeInner) * distance(leftEyeTop, leftEyeBottom);
  const rightEyeSize = distance(rightEyeInner, rightEyeOuter) * distance(rightEyeTop, rightEyeBottom);
  const eyeSizeRatio = Math.min(leftEyeSize, rightEyeSize) / Math.max(leftEyeSize, rightEyeSize);
  const noseWidth = distance(noseLeft, noseRight) / faceWidth;
  const noseLength = distance(noseBridge, noseBottom) / faceLength;
  const mouthWidth = distance(mouthLeft, mouthRight) / faceWidth;
  const chinLength = distance(noseBottom, chin) / faceLength;
  const faceCenterX = (leftFace.x + rightFace.x) / 2;
  const featureCenterX = average([faceTop.x, chin.x, noseBridge.x, noseBottom.x, landmarks[13].x, landmarks[14].x]);
  const centerOffset = Math.abs(featureCenterX - faceCenterX) / faceWidth;
  const leftWidth = Math.abs(featureCenterX - leftFace.x);
  const rightWidth = Math.abs(rightFace.x - featureCenterX);
  const widthSymmetry = 1 - Math.abs(leftWidth - rightWidth) / Math.max(leftWidth, rightWidth);
  const overallSymmetry = clamp((widthSymmetry * .62 + eyeSizeRatio * .38) - centerOffset * .42, 0, 1);

  const faceType = classifyFace(faceRatio, lowerThird, noseWidth, mouthWidth, overallSymmetry);
  const thirdsSpread = Math.max(upperThird, middleThird, lowerThird) - Math.min(upperThird, middleThird, lowerThird);
  const thirdsBalance = clamp(1 - thirdsSpread * 2.8, 0, 1);
  const featureFocus = clamp(1 - Math.abs(eyeSpacing - .22) - Math.abs(noseWidth - .24) - Math.abs(mouthWidth - .39), 0, 1);

  return {
    faceWidth,
    faceLength,
    faceRatio,
    upperThird,
    middleThird,
    lowerThird,
    eyeSpacing,
    eyeSizeRatio,
    noseWidth,
    noseLength,
    mouthWidth,
    chinLength,
    widthSymmetry,
    centerOffset,
    overallSymmetry,
    thirdsBalance,
    featureFocus,
    faceType
  };
}

function classifyFace(faceRatio, lowerThird, noseWidth, mouthWidth, symmetry) {
  if (faceRatio >= 1.48) return "偏长脸";
  if (faceRatio <= 1.16 && lowerThird < .38) return "偏圆脸";
  if (faceRatio <= 1.24 && lowerThird >= .36) return "偏方脸";
  if (noseWidth >= .28 && mouthWidth <= .36) return "菱形脸";
  if (faceRatio >= 1.26 && faceRatio <= 1.44 && symmetry >= .78) return "鹅蛋脸";
  if (faceRatio > 1.4 && mouthWidth < .38) return "偏窄脸";
  return "自然脸型";
}

function scoreFromMetrics(metrics) {
  const thirds = metrics.thirdsBalance * 28;
  const symmetry = metrics.overallSymmetry * 30;
  const focus = metrics.featureFocus * 18;
  const faceRatioScore = (1 - Math.min(Math.abs(metrics.faceRatio - 1.34) / .38, 1)) * 14;
  const eyeScore = metrics.eyeSizeRatio * 10;
  return Math.round(clamp(42 + thirds + symmetry + focus + faceRatioScore + eyeScore - 34, 52, 96));
}

function drawOverlay(landmarks, image) {
  const canvas = refs.canvas;
  const context = canvas.getContext("2d");
  const size = refs.dropZone.getBoundingClientRect().width;
  const scale = Math.max(size / image.width, size / image.height);
  const drawWidth = image.width * scale;
  const drawHeight = image.height * scale;
  const offsetX = (size - drawWidth) / 2;
  const offsetY = (size - drawHeight) / 2;

  canvas.width = Math.round(size * window.devicePixelRatio);
  canvas.height = Math.round(size * window.devicePixelRatio);
  canvas.style.width = `${size}px`;
  canvas.style.height = `${size}px`;
  context.scale(window.devicePixelRatio, window.devicePixelRatio);
  context.clearRect(0, 0, size, size);

  const toCanvas = (point) => ({
    x: offsetX + point.x * drawWidth,
    y: offsetY + point.y * drawHeight
  });

  const drawLine = (indices, color = "rgba(255,255,255,.82)", width = 1.4) => {
    context.beginPath();
    indices.forEach((index, order) => {
      const point = toCanvas(landmarks[index]);
      if (order === 0) context.moveTo(point.x, point.y);
      else context.lineTo(point.x, point.y);
    });
    context.strokeStyle = color;
    context.lineWidth = width;
    context.stroke();
  };

  drawLine([10, 168, 2, 13, 14, 152], "rgba(255,255,255,.92)", 1.5);
  drawLine([234, 93, 132, 58, 172, 136, 150, 149, 176, 148, 152, 377, 400, 378, 379, 365, 397, 288, 361, 323, 454], "rgba(255,255,255,.72)", 1.2);
  drawLine([33, 133, 362, 263], "rgba(216,125,124,.9)", 1.4);
  drawLine([98, 2, 327], "rgba(201,168,106,.9)", 1.4);
  drawLine([61, 13, 291, 14, 61], "rgba(216,125,124,.86)", 1.2);

  [10, 152, 234, 454, 33, 133, 362, 263, 98, 327, 61, 291, 168, 2].forEach((index) => {
    const point = toCanvas(landmarks[index]);
    context.beginPath();
    context.arc(point.x, point.y, 3.4, 0, Math.PI * 2);
    context.fillStyle = "rgba(255,255,255,.96)";
    context.fill();
    context.lineWidth = 1.5;
    context.strokeStyle = "rgba(185,67,67,.8)";
    context.stroke();
  });
}

function clearOverlay() {
  const canvas = refs.canvas;
  const context = canvas.getContext("2d");
  context.clearRect(0, 0, canvas.width, canvas.height);
}

function updateRatio(id, value, min, max) {
  $(id).textContent = value.toFixed(2);
  $(`${id}Bar`).style.setProperty("--bar", metricPercent(value, min, max));
}

function updateMetricsUI(metrics, total) {
  $("overallScore").textContent = total;
  $("scoreNumber").textContent = total;
  $("scoreRing").style.setProperty("--score-angle", `${Math.round(total / 100 * 360)}deg`);
  $("photoState").textContent = "识别完成";
  $("faceType").textContent = metrics.faceType;
  $("thirdsBalance").textContent = `${Math.round(metrics.thirdsBalance * 100)}%`;
  $("symmetryText").textContent = `${Math.round(metrics.overallSymmetry * 100)}%`;
  updateRatio("faceRatio", metrics.faceRatio, 1.05, 1.55);
  updateRatio("eyeSpacing", metrics.eyeSpacing, .16, .34);
  updateRatio("noseWidth", metrics.noseWidth, .16, .34);
  updateRatio("mouthWidth", metrics.mouthWidth, .28, .52);
}

function reportCopy(metrics, total) {
  const thirds = `${Math.round(metrics.upperThird * 100)}:${Math.round(metrics.middleThird * 100)}:${Math.round(metrics.lowerThird * 100)}`;
  const symmetry = Math.round(metrics.overallSymmetry * 100);
  const focus = metrics.featureFocus >= .76 ? "较集中" : metrics.featureFocus >= .55 ? "适中" : "偏舒展";
  const temperament = total >= 84 ? "偏执行型与表达型" : total >= 72 ? "偏稳健型与观察型" : "偏内敛观察型";

  return {
    title: total >= 84 ? "气韵舒展，结构识别稳定" : total >= 72 ? "五官清朗，整体比例协调" : "结构可读，建议补充更清晰照片",
    summary: `AI 已完成人脸关键点识别。当前脸型倾向为${metrics.faceType}，三庭比例约为 ${thirds}，整体对称度约 ${symmetry}%。`,
    overview: `脸型：${metrics.faceType}；五官集中度：${focus}；对称度：${symmetry}%。脸长/脸宽约 ${metrics.faceRatio.toFixed(2)}，整体结构更适合清爽、留白充足的形象表达。`,
    proportion: `上庭、中庭、下庭估算比例约为 ${thirds}。五眼框架中，眼距/脸宽约 ${metrics.eyeSpacing.toFixed(2)}。发际线会受刘海、角度和光线影响，上庭判断为估算，仅作参考。传统文化里三庭均衡常被解读为节律稳定；现代审美里则更偏向比例协调。`,
    features: `眉眼：左右眼大小接近度约 ${Math.round(metrics.eyeSizeRatio * 100)}%。鼻相：鼻宽/脸宽约 ${metrics.noseWidth.toFixed(2)}，鼻长/脸长约 ${metrics.noseLength.toFixed(2)}。口相：嘴宽/脸宽约 ${metrics.mouthWidth.toFixed(2)}。下巴长度/脸长约 ${metrics.chinLength.toFixed(2)}。颧骨与额头受发型和镜头畸变影响较大，系统只做辅助观察。`,
    tcm: `从传统望诊文化角度，可把面部气色理解为精神状态与外在观感的文化参考。本工具不会根据照片判断具体疾病，也不输出医学诊断；若有身体不适，请以专业医生意见为准。`,
    temperament: `娱乐化气质解读：${temperament}。你的面部结构给人的第一印象更偏清晰、克制和有秩序，适合通过稳定表达、自然光线和干净轮廓加强可信度。`,
    advice: `形象建议：选择低饱和、质感干净的服装。拍照建议：正脸自然光，镜头略高于眼睛，避免广角近距离。发型建议：保留额头适度透气感，让三庭比例更清楚。精神状态建议：减少熬夜，让眼神和肤色更舒展。传统文化娱乐评分：${total}。`
  };
}

function renderReport(metrics) {
  const total = scoreFromMetrics(metrics);
  updateMetricsUI(metrics, total);
  const copy = reportCopy(metrics, total);
  $("reportTitle").textContent = copy.title;
  $("reportSummary").textContent = copy.summary;
  $("overviewText").textContent = copy.overview;
  $("proportionText").textContent = copy.proportion;
  $("featuresText").textContent = copy.features;
  $("tcmText").textContent = copy.tcm;
  $("temperamentText").textContent = copy.temperament;
  $("adviceText").textContent = copy.advice;
}

async function analyzeImage(image) {
  if (!state.modelReady || !state.landmarker) {
    setMessage("AI 模型尚未就绪，请稍等片刻后重新上传。", "warning");
    return;
  }

  setMessage("正在本地识别人脸关键点...", "");
  const result = state.landmarker.detect(image);
  const faces = result.faceLandmarks || [];

  if (!faces.length) {
    $("photoState").textContent = "未识别";
    clearOverlay();
    setMessage("未识别到清晰正脸，请上传光线充足、无遮挡、正面角度的照片。", "warning");
    return;
  }

  const selectedIndex = chooseLargestFace(faces);
  const landmarks = faces[selectedIndex];
  const metrics = calculateMetrics(landmarks);
  state.metrics = metrics;
  state.selectedFaceIndex = selectedIndex;

  drawOverlay(landmarks, image);
  renderReport(metrics);

  const multiFaceTip = faces.length > 1 ? "检测到多张人脸，系统已默认选择画面中最大的人脸进行分析。" : "";
  setMessage(`${multiFaceTip} 已在本地完成 ${landmarks.length} 个关键点识别，并自动生成面相文化报告。`, "success");
}

async function handleFile(file) {
  if (!file || !file.type.startsWith("image/")) return;
  try {
    $("photoState").textContent = "读取中";
    setMessage("正在读取照片，照片只会在本地浏览器中处理。", "");
    const { image, dataUrl } = await readImage(file);
    state.image = image;
    refs.photoPreview.src = dataUrl;
    refs.dropZone.classList.add("has-image");
    $("photoState").textContent = "分析中";
    await analyzeImage(image);
  } catch (error) {
    $("photoState").textContent = "读取失败";
    setMessage("照片读取失败，请换一张清晰正脸照片重试。", "warning");
    console.error(error);
  }
}

refs.photoInput.addEventListener("change", (event) => handleFile(event.target.files[0]));
$("uploadBtn").addEventListener("click", () => refs.photoInput.click());

["dragenter", "dragover"].forEach((eventName) => {
  refs.dropZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    refs.dropZone.classList.add("dragging");
  });
});

["dragleave", "drop"].forEach((eventName) => {
  refs.dropZone.addEventListener(eventName, (event) => {
    event.preventDefault();
    refs.dropZone.classList.remove("dragging");
  });
});

refs.dropZone.addEventListener("drop", (event) => {
  handleFile(event.dataTransfer.files[0]);
});

window.addEventListener("resize", () => {
  if (state.image && state.metrics && refs.photoPreview.complete) {
    analyzeImage(state.image);
  }
});

initFaceLandmarker();
